//
//  SaugataLiveStreaming.swift
//  CustomSDK
//
//  Created by Apple on 10/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import Foundation
import AVKit
import AVFoundation
public protocol SaugataProtocols: class {
    func videoPlayingEnded()
}
public class LandscapePlayer: AVPlayerViewController {
    public override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return .landscapeRight
    }
    public override var shouldAutorotate: Bool {
        return false
    }
    open override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        // now, check that this ViewController is dismissing
        if self.isBeingDismissed == false {
            return
        }
        // and then , post a simple notification and observe & handle it, where & when you need to.....
        NotificationCenter.default.post(name: .kAVPlayerViewControllerDismissingNotification, object: nil)
    }
}
extension Notification.Name {
    static let kAVPlayerViewControllerDismissingNotification = Notification.Name.init("dismissing")
}
public class SaugataLiveStreaming: UIViewController, AVPlayerViewControllerDelegate {
    var playerController = LandscapePlayer()
    var playerView = AVPlayer()
    let buttonWidth:CGFloat = 50.0
    weak var delegate: SaugataProtocols?
    public static let sharedInstance: SaugataLiveStreaming = {
        let instance = SaugataLiveStreaming()
        return instance
    }()
    public func addPlayerView(withUrl: String, withDelegate: Any) {
        UIDevice.current.setValue(Int(UIInterfaceOrientation.landscapeRight.rawValue), forKey: "orientation")
        delegate = withDelegate as? SaugataProtocols
        playerView = AVPlayer(url: URL(string: withUrl)!)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
        NotificationCenter.default.addObserver(self, selector: #selector(playerDidFinishPlaying), name: .AVPlayerItemDidPlayToEndTime, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(playerCancelledPlaying), name: .kAVPlayerViewControllerDismissingNotification, object: nil)
        playerController.player = playerView
        playerController.showsPlaybackControls = true
        present(playerController, animated: true) {
            self.playerController.player?.play()
        }
    }
    @objc func playerDidFinishPlaying(note: Notification) {
        print("Video Finished")
        NotificationCenter.default.removeObserver(self)
        UIDevice.current.setValue(Int(UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
        delegate?.videoPlayingEnded()
    }
    @objc func playerCancelledPlaying(note: Notification) {
        print("Video Cancelled\(String(describing: delegate))")
        NotificationCenter.default.removeObserver(self)
        UIDevice.current.setValue(Int(UIInterfaceOrientation.portrait.rawValue), forKey: "orientation")
        delegate?.videoPlayingEnded()
    }
}
