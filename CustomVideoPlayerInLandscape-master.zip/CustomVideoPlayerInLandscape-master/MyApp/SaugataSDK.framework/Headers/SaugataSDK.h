//
//  SaugataSDK.h
//  SaugataSDK
//
//  Created by Apple on 10/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SaugataSDK.
FOUNDATION_EXPORT double SaugataSDKVersionNumber;

//! Project version string for SaugataSDK.
FOUNDATION_EXPORT const unsigned char SaugataSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SaugataSDK/PublicHeader.h>


