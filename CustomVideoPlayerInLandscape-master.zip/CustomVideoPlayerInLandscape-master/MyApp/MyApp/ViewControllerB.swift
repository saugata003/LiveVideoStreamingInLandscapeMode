//
//  ViewControllerB.swift
//  MyApp
//
//  Created by Apple on 10/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
class ViewControllerB: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}
