//
//  ViewControllerA.swift
//  MyApp
//
//  Created by Apple on 10/12/19.
//  Copyright © 2019 Apple. All rights reserved.
//

import UIKit
import SaugataSDK
class ViewControllerA: UIViewController, SaugataProtocols {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    @IBAction func nextButtonPressed(_ sender: UIButton) {
        let controller = SaugataLiveStreaming.sharedInstance
        self.addChild(controller)
        controller.addPlayerView(withUrl: "https://bitdash-a.akamaihd.net/content/MI201109210084_1/m3u8s/f08e80da-bf1d-4e3d-8899-f0f6155f6efa.m3u8", withDelegate: self)
    }
    func videoPlayingEnded() {
        UIView.animate(withDuration: 0.3, animations: {
            self.presentedViewController?.dismiss(animated: true, completion: nil)
        }) { (finished) in
            let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "ViewControllerB")
            self.navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
}
